import express from 'express';
import bodyParser from 'body-parser';
import { v4 as uuidv4 } from 'uuid';

const app = express();
const port = 3000;

let posts = [];

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));

app.listen(port, () => {
    console.log(`Listening on port ${port}`);
});

app.get("/", (req, res) => {
    res.render("home", { posts });
});

app.post("/create", (req, res) => {
    const title = req.body.title;
    const content = req.body.content;
    const post = { id: uuidv4(), title, content };
    posts.push(post);
    res.redirect("/");
});

app.get("/edit/:id",(req,res)=>{
    const newId=req.params.id;
    const postToEdit=posts.find(post=>post.id===newId);
    if(!postToEdit)
    {
        res.status(404).send("post not available");
    }
    else
    {
        res.render("edit.ejs",{post:postToEdit});
    }
});

app.post("/edit/:id",(req,res)=>{
    const editId=req.params.id;
    const {title,content}=req.body;
    const editIndex=posts.findIndex(post=> post.id===editId);

    posts[editIndex].title=title;
    posts[editIndex].content=content;
    res.redirect("/");
});

app.post("/delete/:id",(req,res)=>{
    const deletePost=req.params.id;
    posts=posts.filter(post=>post.id!==deletePost);
    res.redirect("/");
});
